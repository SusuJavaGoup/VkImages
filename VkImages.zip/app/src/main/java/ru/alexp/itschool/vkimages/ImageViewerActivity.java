package ru.alexp.itschool.vkimages;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ArrayAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.ListAdapter;

import java.util.ArrayList;

public class ImageViewerActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_image_viewer);
        loadImages();
    }

    private void loadImages() {
        GridView grid = (GridView) findViewById(R.id.grid);
        ArrayList<VkImage> images = ImageManager.getIstance().getImages();
        ArrayList<ImageView> imgs = new ArrayList<>();
        for (VkImage image : images) {
            imgs.add(image.getImageView(this));
        }
        ListAdapter listadapter = new ArrayAdapter<ImageView>(this, android.R.layout.simple_list_item_1, imgs);
        grid.setAdapter(listadapter);
    }
}
